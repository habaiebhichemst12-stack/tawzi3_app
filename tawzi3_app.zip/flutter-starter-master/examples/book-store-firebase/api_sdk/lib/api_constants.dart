Map<String, String> apiConstants = {"auth": "https://reqres.in/api"};
