# Flutter starter


To start with this app you need to set up few things.

Please refer to the [documentation](https://flutter-starter.github.io/docs/bookstore-firebase-app-example) for the steps.

The demo for the app look like this:

<img style="float: left;" src="./book_store.gif"  height="500"/>
