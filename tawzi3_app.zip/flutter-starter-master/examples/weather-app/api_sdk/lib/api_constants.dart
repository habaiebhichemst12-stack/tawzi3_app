Map<String, String> apiConstants = {
  "openweather": "https://api.openweathermap.org/data/2.5",
  "auth": "https://reqres.in/api"
};

String appId = "76c6d3d3ca02483285a88070bea2cf07";
