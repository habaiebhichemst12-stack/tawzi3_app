library constants;

// Onboarding Screens
const String app_name = "APP NAME";

// tabs
const String tab0 = "Tab 0";
const String tab1 = "Tab 1";
const String tab2 = "Tab 2";
const String tab3 = "Tab 3";

//Screen 1
const String screen_util = "Screen";

//home
const String app_bar_title = 'Weather App';

//Weather Screens
const String enter_city_name = 'Enter City Name Here';
const String search = 'Search';
const String weather_image_const_1 = "http://openweathermap.org/img/wn/";
const String weather_image_const_2 = "@2x.png";
