export 'package:shared/modules/hacker_news/models/data_models/news_item_model.dart';
