Map<String, String> apiConstants = {
  "hacker_news": "https://hacker-news.firebaseio.com/v0",
  "auth": "https://reqres.in/api"
};
