import 'package:flutter/material.dart';
import 'db_helper.dart';

void main() {
  runApp(Tawzi3App());
}

class Tawzi3App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tawzi3 App',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  final DbHelper db = DbHelper();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Tawzi3 - توزيع الدواء')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              child: Text('تبرع'),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => DonationPage()),
                );
              },
            ),
            ElevatedButton(
              child: Text('طلب دواء'),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => RequestPage()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class DonationPage extends StatelessWidget {
  final TextEditingController donorController = TextEditingController();
  final TextEditingController amountController = TextEditingController();
  final DbHelper db