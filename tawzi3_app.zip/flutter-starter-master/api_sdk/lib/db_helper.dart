import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DbHelper {
  static Database? _db;

  Future<Database> get db async {
    if (_db != null) return _db!;
    _db = await initDb();
    return _db!;
  }

  initDb() async {
    String path = join(await getDatabasesPath(), "tawzi3.db");
    return await openDatabase(path, version: 1, onCreate: _onCreate);
  }

  void _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE donations(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        donor TEXT,
        amount INTEGER
      )
    ''');

    await db.execute('''
      CREATE TABLE requests(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient TEXT,
        medicine TEXT
      )
    ''');
  }

  Future<void> insertDonation(String donor, int amount) async {
    final dbClient = await db;
    await dbClient.insert('donations', {'donor': donor, 'amount': amount});
  }

  Future<void> insertRequest(String patient, String medicine) async {
    final dbClient = await db;
    await dbClient.insert('requests', {'patient': patient, 'medicine': medicine});
  }
}