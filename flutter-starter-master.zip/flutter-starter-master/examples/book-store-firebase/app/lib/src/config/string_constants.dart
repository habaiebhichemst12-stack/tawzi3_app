library constants;

// Onboarding Screens
const String app_name = "APP NAME";

// tabs
const String tab0 = "Tab 0";
const String tab1 = "Tab 1";
const String tab2 = "Tab 2";
const String tab3 = "Tab 3";

//Screen 1
const String screen_util = "Screen";

//home
const String app_bar_title = 'Book store';
